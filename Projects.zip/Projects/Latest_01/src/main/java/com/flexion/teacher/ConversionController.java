package com.flexion.teacher;

import org.springframework.web.bind.annotation.*;
@CrossOrigin(origins = "http://localhost:8082")
@RestController
public class ConversionController {

    private int number;
    @GetMapping("/getnumber")
    @ResponseBody
    public int getNumber(@RequestParam int number) {
        return number;
     }
     @GetMapping("/getconversion")
     @ResponseBody
     public float fahrenheitToCelsius(@RequestParam(name = "number") int number){
        FahrenheitToCelsius fahrenheitToCelsius = new FahrenheitToCelsius("number","",number);
        float aa = fahrenheitToCelsius.fahrenheitToCelsius();
        return aa;
    }
    @GetMapping("/getconversion2")
    @ResponseBody
    public double fahrenheitToRankine(@RequestParam(name = "number") int number){
        FahrenheitToCelsius fahrenheitToRankine = new FahrenheitToCelsius("", "", number);
        double aa = fahrenheitToRankine.fahrenheitToRankine();
        return aa;
    }
    @GetMapping("/getconversion3")
    @ResponseBody
    public double fahrenheitToKelvin(@RequestParam(name = "number") int number){
        FahrenheitToCelsius fahrenheitToKelvin = new FahrenheitToCelsius("", "" , number);
        double aa = fahrenheitToKelvin.fahrenheitToRankine();
        return aa;
    }
    @CrossOrigin(origins = "http://localhost:8082")
    @GetMapping("/gettranformation")
    @ResponseBody
    public String calcuate_Transformation_Type(@RequestParam(name = "from_Target" ) String from_Target, @RequestParam(name = "to_Target" ) String to_Target,@RequestParam(name = "number" )  int number) throws Exception {
        FahrenheitToCelsius calcuate_Transformation_Type = new FahrenheitToCelsius(from_Target, to_Target, number);
        String aa = calcuate_Transformation_Type.calcuate_Transformation_Type();
        return aa;
    }
}
