package com.flexion.teacher;

import java.util.Locale;

public class FahrenheitToCelsius {
    private float temperature;
    private int number;
    private String from_Target;
    private String to_Target;

    public FahrenheitToCelsius(String from_Target, String to_Target, int number) {
        this.number = number;
        this.from_Target = from_Target;
        this.to_Target   = to_Target;
    }

    public String calcuate_Transformation_Type() throws Exception {
        float aa;
        String temp = null;

        switch ((from_Target + to_Target).toLowerCase()){
            case "fahrenheitcelsius":
                aa = fahrenheitToCelsius();
                temp = String.valueOf(aa);
                return temp;
            case  "fahrenheittorankine":
                aa = fahrenheitToRankine();
                temp = String.valueOf(aa);
                return temp;
            case  "fahrenheittokelvin":
               aa = fahrenheitToKelvin();
               temp = String.valueOf(aa);
               return temp;
            case "celsiusfahrenheit":
                aa =  CelsiusTofahrenheit();
                temp = String.valueOf(aa);
                return temp;
            case "celsiusrankine":
                aa =  CelsiusToRankine();
                temp = String.valueOf(aa);
                return temp;
            case "celsiuskelvin":
                aa =  CelsiusToKelvin();
                temp = String.valueOf(aa);
                return temp;
            case "rankinecelsius":
                aa =  RankineToCelsius();
                temp = String.valueOf(aa);
                return temp;
            case "kelvinrankine":
                aa =  KelvinToRankine();
                temp = String.valueOf(aa);
                return temp;
            case "kelvincelsius":
                aa =  KelvinToCelsius();
                temp = String.valueOf(aa);
                return temp;
            case "kelevinfahrenheit":
                aa =  KelvinTofahrenheit();
                temp = String.valueOf(aa);
                return temp;
            case "rankinefahrenheit":
                aa =  RankineTofahrenheit();
                temp = String.valueOf(aa);
                return temp;
            case "rankinekelvin":
                aa =  RankineToKelvin();
                temp = String.valueOf(aa);
                return temp;

            default:
                throw new Exception();

         }

    }
    public long getnumber() {
        return number;
    }

    public float fahrenheitToCelsius() {
        return temperature = ((number - 32) * 5 / 9);
    }

    public float fahrenheitToRankine() {
        return (number +459.67f);
    }

    public float fahrenheitToKelvin() {
        return  273.5f + ((number - 32.0f) * (5.0f/9.0f));

    }

    public float CelsiusTofahrenheit(){
        return ( (number * 9)/5)+32;
    }
    public float  CelsiusToRankine() {
        return (number +273.15f)*9f/5f;
    }

    public float  CelsiusToKelvin() {
        return (number  + 273.15f);
    }

    public float KelvinTofahrenheit(){
        return (number *9f/5f-459.67f) ;
    }
    public float  KelvinToRankine() {
        return (number * 9f/5f);
    }

    public float  KelvinToCelsius() {
        return (number-273.15f);
    }

    public float RankineTofahrenheit(){
        return ( number -459.67f);
    }
    public float  RankineToKelvin() {
        return (number *5f/9f);
    }

    public float  RankineToCelsius() {
        return (number -491.67f)*5f/9f;
    }

}


