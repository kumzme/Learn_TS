<template>
  <div id="app">
    <h2> questionaire</h2>

    <div>
      <input v-model="Temp_Input" placeholder="edit me">
      <select v-model="From_Source" placeholder="From Source ">
        <option>Fahrenheit</option>
        <option>Celsius</option>
        <option>Kelvin</option>
        <option>Rankine</option>
      </select>
      <select v-model="To_Source" placeholder="To target">
        <option value="" selected disabled>Choose</option>
        <option>Fahrenheit</option>
        <option>Celsius</option>
        <option>Kelvin</option>
        <option>Rankine</option>
      </select>
      <button v-on:click="greet()">Submit</button>
      <p> Final Converted Results</p>
      <button>{{ Result_After_Conversion }}</button>

    </div>
    <nav>
      <ul>
        <li>
          <router-link :to="{name: 'home'}">Home</router-link>
        </li>
        <li>
          <router-link :to="{name: 'teacher'}">Teacher</router-link>
        </li>
        <li>
          <router-link :to="{name: 'student', params: {id: 2}}">Student</router-link>
        </li>
      </ul>
    </nav>
    <router-view/>
  </div>
</template>

<script>
// eslint-disable-next-line no-unused-vars
import api_Client from "axios";

export default {
  name: "App",
  data() {
    return {
      name: "Student",
      bindingId: 'Questionaire',
      isDisabled: false,
      Fr: '0000',
      From_Source: 'Name of source temperature type',
      To_Source: 'Name of Target temperature type',
      Temp_Input: '0000',
      Result_After_Conversion: 'Results',
      selected: ''
    }
  },
  methods: {
    greet: function (event) {
      // `this` inside methods points to the Vue instance
      // alert('Hello ' + this.name + '!')
      // `event` is the native DOM event
      // eslint-disable-next-line no-unused-vars
      let Url_V = "http://localhost:8083/gettranformation?from_Target=" + this.From_Source + "&to_Target=" + this.To_Source + "&number=" + this.Temp_Input
      api_Client.get(Url_V,
          {
            headers: {
              "Access-Control-Allow-Origin": "http://localhost:8083",
              "Access-Control-Allow-Methods": "GET, POST, PATCH, PUT, DELETE, OPTIONS",
              "Access-Control-Allow-Headers": "Origin, Content-Type, X-Auth-Token"
            }
          }
      ).then((response) => {
        console.log(event);
        console.log(response.data);
        this.Result_After_Conversion = response.data;
      }, (error) => {
        console.log(event);
        console.log(error);
      });
    },
    alertSimpleInput1() {
      alert(this.value1);
    },

    alertSimpleInput2() {
      alert(this.value2);
    },

    changeInput1(newValue) {
      this.value1 = newValue;
    },
  }

}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.underline {
  text-decoration-line: underline;
}
</style>
