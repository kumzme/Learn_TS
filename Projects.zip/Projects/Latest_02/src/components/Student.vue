
<template>
  <div>
    Student ID is: {{ $route.params.id }}
  </div>
</template>
<script>
export default {

}
</script>