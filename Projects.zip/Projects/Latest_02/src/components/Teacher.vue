
<template>
  <div>
    Teacher
  </div>
</template>
<script>
export default {

}
</script>