import Home from './components/Home.vue';
import Student from './components/Student.vue';
import Teacher from './components/Teacher.vue';
import Login from './components/Login.vue';
import Redirect from "@/components/Redirect";



const routes = [
    { path: '/', component: Home },
    { path: '/student/:id', component: Student, name: 'student'  },
    { path: '/teacher', component: Teacher },
    { path: '/login', component: Login},
    { path: '/redirect', component: Redirect}
];

export default routes;
