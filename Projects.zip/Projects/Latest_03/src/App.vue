<template>
  <img alt="Vue logo" src="./assets/logo.png">
  <button v-on:click="Select_Page(1)">Teacher</button>
  <button v-on:click="Select_Page(2)">Student</button>
  <HelloWorld msg="Welcome to Your Vue.js App"/>
  <Teacher v-if="Teacher_Page" msg="Welcome to Your Vue.js App Teacher"/>
  <Student v-if="Student_Page" msg="Welcome to Your Vue.js App Student"/>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import Teacher from './components/Teacher'
import Student from './components/Student'
import {defineComponent} from "vue";


export default defineComponent({
  name: 'App',
  components: {
    HelloWorld,
    Teacher,
    Student
  },
  data() {
    return {
      Teacher_Page: true, Student_Page: false
    }
  },
  methods: {
    Select_Page: function (who) {
      if (who === 1) {
        this.Teacher_Page = true;
        this.Student_Page = false;
        return;
      }
      if (who === 2) {
        console.log("___");
        this.Student_Page = true;
        this.Teacher_Page = false;
        return;
      }
    }
  }
})
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
