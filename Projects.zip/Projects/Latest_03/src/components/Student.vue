<template>
  <div>    <h3>Installed CLI Plugins Student</h3>
  </div>
</template>

<script>

export default {
}

</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
